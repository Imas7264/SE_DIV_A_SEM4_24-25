const userData = JSON.parse(localStorage.getItem('userData'));

if(userData)
{
 const usernameElement = document.getElementById('userDataDisplay');
 usernameElement.textContent = `${userData.Name} / ${userData.MID} / ${userData.Type}`
}
else
{console.log("User data not found.");}

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer, addDoc, orderBy, query, Timestamp} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL, listAll, getMetadata } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);
const storage = getStorage(firebaseapp);

async function displayImage() {
 try
 {
  // Step 1: Get Image URL from Firebase Storage
  const imageRef = ref(storage,'Other/SE-AIML-A.jpg'); // Change to your file path
  const imageUrl = await getDownloadURL(imageRef);

  // Step 2: Set Image Source
  document.getElementById('TimeTable').src = imageUrl;
 } catch (error) {
     console.error("Error fetching image:", error);
 }
}

displayImage();

const InputContainer = document.querySelector('.sidebarWinput'); // Get the parent container

function createInputField()
{
 const inputDiv = document.createElement('div'); // Create a div for the input area
 inputDiv.classList.add('Input'); // Add the 'Input' class for styling

 const input = document.createElement('input');
 input.type = 'text';
 input.classList.add('TypeBox');
 input.placeholder = 'Type here...';

 const sendButton = document.createElement('button');
 sendButton.classList.add('send');
 sendButton.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';


 sendButton.addEventListener('click', () => {
  const message = input.value;
  if (message.trim() !== "")
  {
   const now = new Date();
   const options = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit', 
    hour12: true 
   };

   const formattedDate = now.toLocaleDateString('en-US', options);
   try
   {
    // Add the message to Firestore
     addDoc(collection(db, 'Updates'), { // 'updates' is your collection name
     message: message,
     DatabaseTimestamp: Timestamp.now(),
     timestamp: formattedDate, // Add a timestamp for ordering
     user: `${userData.Name} / ${userData.MID} / ${userData.Type}`
    });

    console.log("Message saved to Firestore:", message);
    input.value = ""; // Clear input field
    displayUpdates();
   }
   catch (error)
   {
    console.error("Error saving message to Firestore:", error);
    // Handle the error (e.g., display an error message to the user)
    alert("Error sending message. Please try again later.")
   }
  }
 });


 inputDiv.appendChild(input);
 inputDiv.appendChild(sendButton);
 InputContainer.appendChild(inputDiv); // Add input to container
}


// Call the function to create the input field when the page loads
window.addEventListener('DOMContentLoaded', () => {
});

if(userData.Type == 'Admin')
{createInputField();}

async function displayUpdates()
{
 const updatesContainer = document.querySelector('.updates table'); // Assuming you have a table with class 'updates'
 updatesContainer.innerHTML = ''; // Clear existing updates

 try
 {
  const querySnapshot = await getDocs(
   query(collection(db, 'Updates'), orderBy('DatabaseTimestamp', 'desc'))
  );
  querySnapshot.forEach((doc) => {
   const updateData = doc.data();
   const row = updatesContainer.insertRow();
   const cell = row.insertCell();

   const message = updateData.message;
   const timestamp = updateData.timestamp || "Unknown"; // Handle potential missing timestamps
   const user = updateData.user || "Unknown User"; // Handle cases where user data might be missing

   cell.innerHTML = `${message}<br><p>By ${user} on  ${timestamp}</p>`;
  });
 } catch (error) {
     console.error("Error fetching updates from Firestore:", error);
 }
}

displayUpdates();