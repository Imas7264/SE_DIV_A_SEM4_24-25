const userData = JSON.parse(localStorage.getItem('userData'));

if (userData) {
  const usernameElement = document.getElementById('userDataDisplay');
  usernameElement.textContent = `${userData.Name} / ${userData.MID} / ${userData.Type}`;
} else {
  console.log("User data not found.");
}

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
// import { getFirestore, collection, getDocs, getCountFromServer} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL, listAll, getMetadata } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
// const db = getFirestore(firebaseapp);
const storage = getStorage(firebaseapp);
const storageRef = ref(storage);

function listCategories(folderName)
{
 // alert(`Listing files in folder: ${folderName}`);
 const Topic_Name = document.getElementById('Topic_Name');
 Topic_Name.textContent = `${folderName}`;
 const folderRef = ref(storage, folderName);
 listAll(folderRef)
 .then((res) =>
 {
  const foldersTable = document.getElementById("CategoriesTable");
  foldersTable.innerHTML = "";

  if (res.prefixes.length > 0)
  {
   const firstFolder = res.prefixes[0].name;
   listFiles(firstFolder);
  } else
  {console.log("No folders found.");}

  res.prefixes.forEach((folderRef) =>
  {
   const folderName = folderRef.name;
   const row = document.createElement('th');
   const cell = document.createElement('td');
   cell.innerHTML = `<i class="fa-solid fa-box"></i> ${folderName}`;
   cell.addEventListener('click', () =>
   {listFiles(folderRef);});
   row.appendChild(cell);
   foldersTable.appendChild(row);
  });
 })
 .catch((error) =>
 {console.error("Error listing files:", error);});
}

function listTopics()
{
 listAll(storageRef)
 .then((res) =>
 {
  const foldersTable = document.getElementById("foldersTable");
  foldersTable.innerHTML = "";

  if (res.prefixes.length > 0)
  {
   const firstFolder = res.prefixes[0].name;
   listCategories(firstFolder);
  } else {
    console.log("No folders found.");
  }

  res.prefixes.forEach((folderRef) =>
  {
   const folderName = folderRef.name;
   const row = document.createElement('tr');
   const cell = document.createElement('td');
   cell.innerHTML = `<i class="fa-solid fa-box"></i> ${folderName}`;
   cell.addEventListener('click', () =>
   {listCategories(folderName);});
   row.appendChild(cell);
   foldersTable.appendChild(row);
  });
 })
 .catch((error) =>
 {console.error("Error listing folders:", error);});
}

function listFiles(folderRef)
{
 const folderName = folderRef.name;
 // alert("Listing files in folder: "+folderName);

 listAll(folderRef)
 .then((res) =>
 {
  const LIST = document.getElementById("LIST");
  LIST.innerHTML = "";
  
  res.items.forEach((itemRef) =>
  {
   const fileName = itemRef.name;
   const row = document.createElement('tr');
   const cell = document.createElement('td');
   Promise.all([getDownloadURL(itemRef), getMetadata(itemRef)])
   .then(([downloadURL, metadata]) =>
   {
    const fileSize = metadata.customMetadata?.size || 'Unknown size';
    const creationTime = metadata.customMetadata?.Time || 'Unknown Time';
    const uploadedBy = metadata.customMetadata?.byUser || "Unknown user";
    const description = metadata.customMetadata?.FileDescription || "None";
    // console.log(metadata.timeCreated, creationTime.toLocaleString());

    cell.innerHTML = `
      <i class="fa-solid fa-file-lines"></i>  
      <a href="${downloadURL}" target="_blank">${fileName}</a>
      <br>
      <span>Size: ${fileSize}</span>
      <span>By: ${uploadedBy}</span>
      <span><abbr title="${description}">Description</abbr></span>
      <span>Uploaded on: ${creationTime}</span>
    `;
   })
   .catch((error) => {
     console.error("Error getting download URL:", error);
     cell.innerHTML = `
       <i class="fa-solid fa-file-lines"></i>  
       ${fileName} (Download failed)
     `;
   });

 row.appendChild(cell);
 LIST.appendChild(row);
  });
 })
 .catch((error) =>
 {console.error("Error listing files:", error);});
}


listTopics();