const userData = JSON.parse(localStorage.getItem('userData'));
const UserMID = userData.MID;
const UserName = userData.Name;
const UserType = userData.Type;

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer, addDoc, updateDoc, doc, setDoc} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import {getStorage, ref, uploadBytes, getDownloadURL} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js'

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);
// const storage = getStorage(firebaseapp);
// const storageRef = ref(storage);




const UploadFile = document.getElementById("UpdateTask");
UploadFile.addEventListener("click", async function UpdateTask()
{
 const taskName = document.getElementById('taskName').value;
 const subName = document.getElementById("topic").value;
 const dueDate = document.getElementById("dueDate").value;
 // const path = `User/${subName}/Tasks`;

 if(taskName && subName && dueDate)
 {
  try
  {
   const querySnapshot = await getDocs(collection(db, `Users`));

   querySnapshot.forEach(async (docu) => {
    await addDoc(collection(db, `Users/${docu.id}/Tasks/${subName}/Tasks`), { // 'updates' is your collection name
     taskName: taskName,
     dueDate: dueDate,
     status: "Pending"
    });
   });
  
   console.log("Task updated: ", taskName);
   // window.location.href = "TeacherHomepage.html";
  }
  catch (error)
  {
   console.error("Error updating task to Firestore:", error);
   // Handle the error (e.g., display an error message to the user)
   alert("Error updating task. Please try again later.")
  }
 }
 else
 {alert("Please give inputs for all fields");}
 
});