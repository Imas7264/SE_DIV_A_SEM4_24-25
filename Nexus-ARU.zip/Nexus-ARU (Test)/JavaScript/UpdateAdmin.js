const userData = JSON.parse(localStorage.getItem('userData'));
const UserMID = userData.MID;
const UserName = userData.Name;
const UserType = userData.Type;

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer, addDoc, updateDoc, doc, setDoc} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import {getStorage, ref, uploadBytes, getDownloadURL} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js'

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);
const usersRef = collection(db, "Users");

const UploadAccess = document.getElementById("UpdateAccess");
UploadAccess.addEventListener("click", async function UpdateTask()
{
 const MID = document.getElementById("MID").value;
 const Type = document.getElementById("Access").value;
 console.log(MID, Type);
 if(MID && Type!="Select Access")
 {find(MID, Type);}
 else
 {alert("Please give inputs for both the fields.");}
});



function find(MID, Type)
{
 let userExists = false;
  getDocs(usersRef)
  .then((querySnapshot) =>
   {
    querySnapshot.forEach((doc) => 
    {
     if(MID == doc.data().MID)
     {
      userExists =true;
      console.log("Match found. Updating Acess")
      
      updateAccess(doc, Type)
     }
     });
 
    if(!userExists)
    {alert("No such user exists.");}
    
   }).catch((error) =>
   {console.error("Error getting documents:", error);});
}

async function updateAccess(docu, Type)
{
 const docRef = doc(db, "Users", docu.id)
 try{ await updateDoc(docRef, {Type: Type}); alert("Access Updated");}
 catch(error){console.log(error);}
}