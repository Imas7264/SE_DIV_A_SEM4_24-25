const userData = JSON.parse(localStorage.getItem('userData'));
const UserMID = userData.MID;
const UserName = userData.Name;
const UserType = userData.Type;

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer, serverTimestamp} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import {getStorage, ref, uploadBytes, getDownloadURL} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js'

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
// const db = getFirestore(firebaseapp);
const storage = getStorage(firebaseapp);

const now = new Date();
const options = { 
 year: 'numeric', 
 month: 'short', 
 day: 'numeric', 
 hour: '2-digit', 
 minute: '2-digit', 
 hour12: true 
};

const formattedDate = now.toLocaleDateString('en-US', options);
console.log(formattedDate);


const UploadFile = document.getElementById("UploadFile");
UploadFile.addEventListener("click", function uploadFile()
{
 const fileInputXl = document.getElementById('fileInputXl');
 const fileInputJpg = document.getElementById('fileInputJpg');
 const fileXl = fileInputXl.files[0];
 const fileJpg = fileInputJpg.files[0];
 if(fileXl & fileInputJpg)
 {
  const storageRefXl = ref(storage, `Other/${fileXl.name}`);
  const storageRefJpg = ref(storage, `Other/${fileJpg.name}`);
  var customMetadataJpg;
  var customMetadataXl;

  if(fileXl.name == "SE-AIML-A.xlsx")
  {
   const fileXlSizeInMB = ((fileXl.size)/(1024*1024)).toFixed(5);

   customMetadataXl = 
   {
    size: `${fileXlSizeInMB}MB`,
    byUser: `${UserName} / ${UserMID} / ${UserType}`,
    Time: `${formattedDate}`
   }
   console.log(customMetadataXl);
   
   // alert("Schedule Updated");
  }
  else
  {alert("Invalid file name!!! Please name the file as SE-AIML-A.xlsx");}

  if(fileJpg.name == "SE-AIML-A.jpg")
  {
   const fileJpgSizeInMB = ((fileJpg.size)/(1024*1024)).toFixed(5);
   
   customMetadataJpg = 
   {
    size: `${fileJpgSizeInMB}MB`,
    byUser: `${UserName} / ${UserMID} / ${UserType}`,
    Time: `${formattedDate}`
   }

   console.log(customMetadataJpg);
   uploadBytes(storageRefXl, fileXl, {customMetadataXl})
   uploadBytes(storageRefJpg, fileJpg, {customMetadataJpg})
   alert("Schedule Updated");
   window.location.href="TeacherHomepage.html";
  }
  else
  {alert("Invalid file name!!! Please name the file as SE-AIML-A.jpg");}
 }
 else
 {alert('Select an excel & a jpeg file');}
});