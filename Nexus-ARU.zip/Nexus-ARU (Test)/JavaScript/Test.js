const fileInput = document.getElementById('uploadExcel');
const output = document.getElementById('excelTable');

fileInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) {
    return;
  }

  const reader = new FileReader();

  reader.onload = (e) => {
    const data = e.target.result;
    const workbook = XLSX.read(data, { type: 'binary' }); // Important for binary files (Excel)

    // Get the first worksheet (you can access others by name or index)
    const worksheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[worksheetName];

    // Convert worksheet to JSON (easier to work with)
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); // header:1 gets the first row as headers

    displayTable(jsonData); // Call a function to display the data
  };

  reader.readAsBinaryString(file); // Crucial for Excel files
});

function displayTable(data) {
  const table = document.createElement('table');
  table.border = '1'; // Add a border (optional)

  // Create table header
  const headerRow = table.insertRow();
  data[0].forEach(headerText => {  // Assuming the first row is the header
      const headerCell = headerRow.insertCell();
      headerCell.textContent = headerText;
  });

  // Create table rows and cells
  for (let i = 1; i < data.length; i++) { // Start from 1 to skip header row
      const rowData = data[i];
      const row = table.insertRow();
      rowData.forEach(cellData => {
          const cell = row.insertCell();
          cell.textContent = cellData;
      });
  }


  output.innerHTML = ''; // Clear previous table
  output.appendChild(table);
}



export function hello()
{console.log("Hello world");}