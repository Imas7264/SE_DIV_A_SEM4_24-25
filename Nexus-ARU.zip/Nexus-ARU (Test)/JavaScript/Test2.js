import {hello} from './Test.js';

const btn = document.getElementById("Hello");

btn.addEventListener('click', (e) => {hello()});