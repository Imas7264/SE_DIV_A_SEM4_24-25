const userData = JSON.parse(localStorage.getItem('userData'));
const UserMID = userData.MID;
const UserName = userData.Name;
const UserType = userData.Type;

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer, serverTimestamp} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import {getStorage, ref, uploadBytes, getDownloadURL} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js'

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
// const db = getFirestore(firebaseapp);
const storage = getStorage(firebaseapp);
const storageRef = ref(storage);



const topicSelect = document.getElementById("topic");
const categorySelect = document.getElementById("category");

topicSelect.addEventListener("change", () => 
{
 categorySelect.innerHTML = "";
 categorySelect.disabled = false;

 switch (topicSelect.value)
 {
  case "OOP with Java":
   addCategoryOption("Experiments");
   addCategoryOption("Assignments");
   addCategoryOption("Notes");
   addCategoryOption("Other");
   break;

  case "Digital Logic & Computer Architecture":
   addCategoryOption("Experiments");
   addCategoryOption("Assignments");
   addCategoryOption("Notes");
   addCategoryOption("Other");
   break;

  case "Engineering Mathematics - 3":
   addCategoryOption("Tutorials");
   addCategoryOption("Notes");
   addCategoryOption("Other");
   break;

  case "Discrete Structure & Graph Theory":
   addCategoryOption("Assignments");
   addCategoryOption("Notes");
   addCategoryOption("Other");
   break;
 
  case "Data Structures":
   addCategoryOption("Experiments");
   addCategoryOption("Assignments");
   addCategoryOption("Notes");
   addCategoryOption("Other");
   break;

  case "Computer Graphics":
   addCategoryOption("Experiments");
   addCategoryOption("Assignments");
   addCategoryOption("Notes");
   addCategoryOption("Other");
   break;

  case "Other":
   addCategoryOption("Other");
   break;

  default:
  break;
 }
});

function addCategoryOption(category)
{
 const option = document.createElement("option");
 option.value = category;
 option.text = category;
 categorySelect.appendChild(option);
}



const UploadFile = document.getElementById("UploadFile");
UploadFile.addEventListener("click", function uploadFile()
{
 const fileInput = document.getElementById('fileInput');
 const file = fileInput.files[0];
 const topic = document.getElementById('topic');
 if(topic.value == 'Select a Topic')
 {alert('Select a valid Topic');}
 else
 {
 const category = document.getElementById('category');

 if(file)
 {
  const fileSizeInBytes = file.size;
  const fileSizeInKB = (fileSizeInBytes / 1024).toFixed(5);
  const fileSizeInMB = (fileSizeInKB / 1024).toFixed(5);

  const now = new Date();
  const options = { 
   year: 'numeric', 
   month: 'short', 
   day: 'numeric', 
   hour: '2-digit', 
   minute: '2-digit', 
   hour12: true 
  };

 const formattedDate = now.toLocaleDateString('en-US', options);
 console.log(formattedDate);

  // Store the file size in a variable for later use
  const fileSizeData =
  {
   sizeInBytes: fileSizeInBytes,
   sizeInKB: fileSizeInKB,
   sizeInMB: fileSizeInMB
  };

  const customMetadata = 
  {
   size: `${fileSizeInMB}MB`,
   byUser: `${UserName} / ${UserMID} / ${UserType}`,
   FileDescription: (document.getElementById('FileDescription')).value,
   Time: `${formattedDate}`
  }
  console.log(customMetadata);
  const storageRef = ref(storage, `${topic.value}/${category.value}/${file.name}`);
  uploadBytes(storageRef, file, {customMetadata})
  alert("Uploaded: "+file.name+"\nTopic: "+topic.value+"\nCategory: "+category.value);
    
 }
 else
 {alert('Select a File');}
 }
});