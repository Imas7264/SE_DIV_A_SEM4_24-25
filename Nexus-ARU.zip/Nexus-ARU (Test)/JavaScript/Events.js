const userData = JSON.parse(localStorage.getItem('userData'));
console.log(userData);

if (userData) {
  const usernameElement = document.getElementById('userDataDisplay');
  usernameElement.textContent = `${userData.Name} / ${userData.MID} / ${userData.Type}`;
} else {
  console.log("User data not found.");
}

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, addDoc, orderBy, Timestamp, query } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';

const firebaseConfig = {
  apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
  authDomain: "nexus-aru.firebaseapp.com",
  projectId: "nexus-aru",
  storageBucket: "nexus-aru.appspot.com",
  messagingSenderId: "473949076344",
  appId: "1:473949076344:web:d3485fb2eb4d080299268d",
  measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);

const InputContainerImp = document.querySelector('.ImpEvents'); 
const InputContainerOp = document.querySelector('.OpEvents'); 
const ImpPath = 'Events/Important/Events';
const OpPath = 'Events/Optional/Events';

// API endpoint for triggering email notifications
const API_ENDPOINT = 'http://localhost:3001/api/events';

// Function to send notification via API
async function sendNotificationToAPI(message, timestamp, user) {
  try {
    const response = await fetch(API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        timestamp,
        user
      })
    });
    
    const result = await response.json();
    if (!result.success) {
      throw new Error('Failed to send notification');
    }
    
    return true;
  } catch (error) {
    console.error("Error sending notification:", error);
    return false;
  }
}


function createImpInputField() {
  const inputDiv = document.createElement('div');
  inputDiv.classList.add('ImpInput');
  
  const input = document.createElement('input');
  input.type = 'text';
  input.classList.add('TypeBox');
  input.placeholder = 'Type here...';
  
  const sendButton = document.createElement('button');
  sendButton.classList.add('ImpInput');
  sendButton.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';
  
  // Function to handle sending the message
  const sendMessage = async () => {
    const message = input.value;
    if (message.trim() !== "") {
      const now = new Date();
      const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      };
      
      const formattedDate = now.toLocaleDateString('en-US', options);
      const user = `${userData.Name} / ${userData.MID} / ${userData.Type}`;
      
      try {
        // First, add to Firestore as usual
        await addDoc(collection(db, ImpPath), {
          message: message,
          timestamp: formattedDate,
          user: user
        });
        
        // For important events, also send email notification via API
        await sendNotificationToAPI(message, formattedDate, user);
        
        console.log("Message saved to Firestore:", message);
        input.value = "";
        
        displayImpEvents();
      } catch (error) {
        console.error("Error saving message to Firestore:", error);
        alert("Error sending message. Please try again later.");
      }
    }
  };
  
  // Add click event listener to the send button
  sendButton.addEventListener('click', sendMessage);
  
  // Add keypress event listener to the input field
  input.addEventListener('keypress', (event) => {
    // Check if Enter key was pressed
    if (event.key === 'Enter') {
      event.preventDefault(); // Prevent default behavior of Enter key
      sendMessage(); // Call the same function as the button click
    }
  });
  
  inputDiv.appendChild(input);
  inputDiv.appendChild(sendButton);
  InputContainerImp.appendChild(inputDiv);
}


if (userData.Type == 'Admin' || userData.Type == 'Teacher') {
  createImpInputField();
}

function createOpInputField() {
  const inputDiv = document.createElement('div');
  inputDiv.classList.add('OpInput');
  
  const input = document.createElement('input');
  input.type = 'text';
  input.classList.add('TypeBox');
  input.placeholder = 'Type here...';
  
  const sendButton = document.createElement('button');
  sendButton.classList.add('OpInput');
  sendButton.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';
  
  // Create a function for the submit action to avoid code duplication
  const submitMessage = async () => {
    const message = input.value;
    if (message.trim() !== "") {
      const now = new Date();
      const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      };
      
      const formattedDate = now.toLocaleDateString('en-US', options);
      const user = `${userData.Name} / ${userData.MID} / ${userData.Type}`;
      
      try {
        // Add to Firestore
        await addDoc(collection(db, OpPath), {
          message: message,
          DatabaseTimestamp: Timestamp.now(),
          timestamp: formattedDate,
          user: user
        });
        
        // For optional events, only send notification if it includes a notification marker
        // if (message.includes("[NOTIFY]")) {
        //   await sendNotificationToAPI(message, formattedDate, user);
        // }
        await sendNotificationToAPI(message, formattedDate, user);

        
        console.log("Message saved to Firestore:", message);
        input.value = "";
        
        displayOpEvents();
      } catch (error) {
        console.error("Error saving message to Firestore:", error);
        alert("Error sending message. Please try again later.");
      }
    }
  };

  // Add click event listener to the button
  sendButton.addEventListener('click', submitMessage);
  
  // Add keypress event listener to the input field
  input.addEventListener('keypress', (event) => {
    // Check if the pressed key is Enter
    if (event.key === 'Enter') {
      event.preventDefault(); // Prevent default form submission behavior
      submitMessage();
    }
  });
  
  inputDiv.appendChild(input);
  inputDiv.appendChild(sendButton);
  InputContainerOp.appendChild(inputDiv);
}
if (userData.Type == 'Admin' || userData.Type == 'Teacher') {
  createOpInputField();
}

async function displayImpEvents() {
  const updatesContainer = document.querySelector('.ImpEvents .Events table');
  updatesContainer.innerHTML = ''; 

  try {
    const querySnapshot = await getDocs(
      query(collection(db, ImpPath), orderBy('timestamp', 'desc'))
    );
    querySnapshot.forEach((doc) => {
      const updateData = doc.data();
      const row = updatesContainer.insertRow();
      const cell = row.insertCell();

      const message = updateData.message;
      const timestamp = updateData.timestamp || "Unknown"; 
      const user = updateData.user || "Unknown User"; 

      // Allow for clickable links
      const messageWithLinks = message.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');
      cell.innerHTML = `${messageWithLinks}<br><p>By ${user} on ${timestamp}</p>`;
    });
  } catch (error) {
    console.error("Error fetching updates from Firestore:", error);
  }
}

displayImpEvents();

async function displayOpEvents() {
  const updatesContainer = document.querySelector('.OpEvents .Events table');
  updatesContainer.innerHTML = ''; 

  try {
    const querySnapshot = await getDocs(
      query(collection(db, OpPath), orderBy('timestamp', 'desc'))
    );
    querySnapshot.forEach((doc) => {
      const updateData = doc.data();
      const row = updatesContainer.insertRow();
      const cell = row.insertCell();

      const message = updateData.message;
      const timestamp = updateData.timestamp || "Unknown"; 
      const user = updateData.user || "Unknown User"; 

      // Allow for clickable links
      const messageWithLinks = message.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');
      cell.innerHTML = `${messageWithLinks}<br><p>By ${user} on ${timestamp}</p>`;
    });
  } catch (error) {
    console.error("Error fetching updates from Firestore:", error);
  }
}

displayOpEvents();

// Notification for sending email
const sendButton = document.getElementById('sendButton');
if (sendButton) {
  sendButton.addEventListener('click', async () => {
    const message = document.getElementById('input').value;
    if (message.trim() !== "") {
      const now = new Date();
      const formattedDate = now.toLocaleString();
      const user = `${userData.Name} / ${userData.MID} / ${userData.Type}`;

      try {
        // Add to Firestore Events collection
        await addDoc(collection(db, 'Events'), {
          message: message,
          timestamp: formattedDate,
          user: user
        });
        
        // Send notification via API
        const notificationSent = await sendNotificationToAPI(message, formattedDate, user);
        
        if (notificationSent) {
          console.log("Event added successfully, email will be sent.");
        } else {
          console.log("Event added successfully, but email notification failed.");
        }
        
        document.getElementById('input').value = "";
      } catch (error) {
        console.error("Error adding event:", error);
        alert("Error sending event. Try again later.");
      }
    }
  });
}