const userData = JSON.parse(localStorage.getItem('userData'));
console.log(userData);

if(userData)
{
 const usernameElement = document.getElementById('userDataDisplay');
 usernameElement.textContent = `${userData.Name} / ${userData.MID}`
}
else
{console.log("User data not found.");}