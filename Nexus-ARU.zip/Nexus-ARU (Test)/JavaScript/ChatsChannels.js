const userDocID = JSON.parse(localStorage.getItem('userDocID'));
const userData = JSON.parse(localStorage.getItem('userData'));
console.log(userDocID);
console.log(userData);

if(userData)
{
 const usernameElement = document.getElementById('userDataDisplay');
 usernameElement.textContent = `${userData.Name} / ${userData.MID} / ${userData.Type}`
}
else
{console.log("User data not found.");}

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer, updateDoc, doc, query, orderBy, addDoc, Timestamp} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);
const reqRef = collection(db, "Requests");

// Function to populate the table
function populateTable() 
{
  getDocs(reqRef).then((querySnapshot) => 
  {
   const tableBody = document.getElementById("tableBody");
   tableBody.innerHTML = ""; // Clear existing data

   querySnapshot.forEach((doc) =>
   {
    const ChannelName = doc.id;
    if(doc.id=='A' || doc.id==userData.Batch)
    {
     const row = document.createElement('tr');
     const cell = document.createElement('td');
     cell.innerHTML = `<i class="fa-solid fa-comments"></i> ${ChannelName}`;
     cell.addEventListener('click', () =>
     {listRequests(ChannelName);});
     row.appendChild(cell);
     tableBody.appendChild(row);
    }
   });
  })  
  .catch((error) =>
  {console.error("Error getting documents:", error);});
}

async function listRequests(ChannelName)
{
 clearInputField();
 createInputField(ChannelName);
 const reqContainer = document.querySelector(".RequestHistory table")
 reqContainer.innerHTML='';
 const Channel_Name = document.getElementById('Channel_Name');
 Channel_Name.textContent = `${ChannelName}`;
 const channelRef = collection(reqRef,`${ChannelName}/Requests`);

 try
  {
   const querySnapshot = await getDocs(query(channelRef, orderBy('DatabaseTimestamp', 'desc')));
   querySnapshot.forEach((doc) => {
    console.log(doc);
    const req = doc.data();
    console.log(req.DatabaseTimestamp);
    const row = reqContainer.insertRow();
 

    const message = req.Request;
    const timestamp = req.timestamp || "Unknown"; 
    const user = req.User || "Unknown User"; 

    const ReqName = row.insertCell();
    ReqName.innerHTML =  `${message}<br><p>By ${user} on ${timestamp}</p>`;
 
    const statusCell = row.insertCell();
 
    const pendingRadio = document.createElement("input");
    pendingRadio.type = "radio";
    pendingRadio.name = `status-${doc.id}`;
    pendingRadio.id = `pending-${doc.id}`;
    pendingRadio.value = "Pending";
    pendingRadio.checked = req.status === "Pending";
 
    const completedRadio = document.createElement("input");
    completedRadio.type = "radio";
    completedRadio.name = `status-${doc.id}`;
    completedRadio.id = `completed-${doc.id}`;
    completedRadio.value = "Completed";
    completedRadio.checked = req.status === "Completed";
 
    const pendingLabel = document.createElement("label");
    pendingLabel.htmlFor = `pending-${doc.id}`;
    pendingLabel.textContent = "Pending   ";
 
    const completedLabel = document.createElement("label");
    completedLabel.htmlFor = `completed-${doc.id}`;
    completedLabel.textContent = "Completed";
 
    statusCell.appendChild(pendingRadio);
    statusCell.appendChild(pendingLabel);
    statusCell.appendChild(completedRadio);
    statusCell.appendChild(completedLabel);
    
    if(`${userData.Name} / ${userData.MID} / ${userData.Type}` == req.User)
    {
     pendingRadio.addEventListener("change", () => updateRequestStatus(doc.id, pendingRadio.value, ChannelName));
     completedRadio.addEventListener("change", () => updateRequestStatus(doc.id, completedRadio.value, ChannelName));
    }
   });
  }
  catch(e)
  {console.error("Error fetching tasks:", e);}
}


async function updateRequestStatus(ReqId, newStatus, ChannelName)
{
 try {
   const taskRef = doc(db, `Requests/${ChannelName}/Requests`, ReqId);
   await updateDoc(taskRef, { status: newStatus });
   console.log(`Task ${ReqId} status updated to ${newStatus}`);
 } catch (error) {
   console.error("Error updating task status:", error);
   alert("Error updating task status. Please try again.");
 }
}


const InputContainer = document.querySelector('.messageInput');

function createInputField(ChannelName)
{
 const inputDiv = document.createElement('div'); // Create a div for the input area
 inputDiv.classList.add('Input'); // Add the 'Input' class for styling

 const input = document.createElement('input');
 input.type = 'text';
 input.classList.add('TypeBox');
 input.placeholder = 'Type here...';

 const sendButton = document.createElement('button');
 sendButton.classList.add('send');
 sendButton.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';


 sendButton.addEventListener('click', () => {
  const message = input.value;
  if (message.trim() !== "")
  {
   const now = new Date();
   const options = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit', 
    hour12: true 
   };

   const formattedDate = now.toLocaleDateString('en-US', options);
   try
   {
    // Add the message to Firestore
     addDoc(collection(db, `Requests/${ChannelName}/Requests`), { 
     Request: message,
     DatabaseTimestamp: Timestamp.now(),
     timestamp: formattedDate, // Add a timestamp for ordering
     status:"Pending",
     User: `${userData.Name} / ${userData.MID} / ${userData.Type}`
    });

    console.log("Message saved to Firestore:", message);
    input.value = ""; // Clear input field
    listRequests(ChannelName);
   }
   catch (error)
   {
    console.error("Error saving message to Firestore:", error);
    // Handle the error (e.g., display an error message to the user)
    alert("Error sending message. Please try again later.")
   }
  }
 });

 inputDiv.appendChild(input);
 inputDiv.appendChild(sendButton);
 InputContainer.appendChild(inputDiv);
}

function clearInputField()
{document.querySelectorAll(".Input").forEach(div => div.remove());}

populateTable();
listRequests('A');