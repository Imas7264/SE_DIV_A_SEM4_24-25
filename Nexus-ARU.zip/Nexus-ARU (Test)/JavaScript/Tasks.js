const userDocID = JSON.parse(localStorage.getItem('userDocID'));
const userData = JSON.parse(localStorage.getItem('userData'));
console.log(userDocID);
console.log(userData);

if(userData)
{
 const usernameElement = document.getElementById('userDataDisplay');
 usernameElement.textContent = `${userData.Name} / ${userData.MID} / ${userData.Type}`
}
else
{console.log("User data not found.");}

// import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
// import { getFirestore, collection, getDocs, getCountFromServer, addDoc, orderBy, query} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
// // import { getStorage, ref, uploadBytes, getDownloadURL, listAll, getMetadata } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';


import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, getDocs, orderBy, doc, updateDoc, query} from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);

async function ListSubjects()
{
 const sidebar = document.querySelector('.sidebar table');
 sidebar.innerHTML = '';

 try
 {
  const querySnapshot = await getDocs(collection(db, `Subjects`));
  querySnapshot.forEach((doc) => {
   const subData = doc.data();
   const row = sidebar.insertRow();
   const cell = row.insertCell();

   const subName = subData.Name;
   cell.addEventListener('click', () => {ListTasks(subName)});
   cell.innerHTML = `${subName}`;
  });
 } catch (error) {
     console.error("Error fetching docs from Firestore:", error);
 }
}

ListSubjects();

async function ListTasks(subName)
{
 const selectedSub = document.querySelector('.TopicHeader span');
 selectedSub.textContent = subName;
 const tasks = document.querySelector('.Tasks table');
 tasks.innerHTML ='';
 const header = tasks.insertRow();
 
 const headerNameCell = document.createElement("th");
 headerNameCell.textContent = 'Task Name';

 const headerDDCell = document.createElement("th");
 headerDDCell.textContent = 'Due Date';

 const headerStatusCell = document.createElement("th");
 headerStatusCell.textContent = 'Status';

 header.appendChild(headerNameCell);
 header.appendChild(headerDDCell);
 header.appendChild(headerStatusCell);

 try
 {
  const querySnapshot = await getDocs(query(collection(db, `Users/${userDocID}/Tasks/${subName}/Tasks`), orderBy('dueDate', 'asc')));
  querySnapshot.forEach((doc) => {
   const tk = doc.data();
   const row = tasks.insertRow();

   const taskNameCell = row.insertCell();
   taskNameCell.innerHTML = tk.taskName;

   const taskDueDateCell = row.insertCell();
   taskDueDateCell.innerHTML = tk.dueDate;

   const statusCell = row.insertCell();

   const pendingRadio = document.createElement("input");
   pendingRadio.type = "radio";
   pendingRadio.name = `status-${doc.id}`;
   pendingRadio.id = `pending-${doc.id}`;
   pendingRadio.value = "Pending";
   pendingRadio.checked = tk.status === "Pending";

   const completedRadio = document.createElement("input");
   completedRadio.type = "radio";
   completedRadio.name = `status-${doc.id}`;
   completedRadio.id = `completed-${doc.id}`;
   completedRadio.value = "Completed";
   completedRadio.checked = tk.status === "Completed";

   const pendingLabel = document.createElement("label");
   pendingLabel.htmlFor = `pending-${doc.id}`;
   pendingLabel.textContent = "Pending   ";

   const completedLabel = document.createElement("label");
   completedLabel.htmlFor = `completed-${doc.id}`;
   completedLabel.textContent = "Completed";

   statusCell.appendChild(pendingRadio);
   statusCell.appendChild(pendingLabel);
   statusCell.appendChild(completedRadio);
   statusCell.appendChild(completedLabel);

   pendingRadio.addEventListener("change", () => updateTaskStatus(doc.id, pendingRadio.value, subName));
   completedRadio.addEventListener("change", () => updateTaskStatus(doc.id, completedRadio.value, subName));
  });
 }
 catch(e)
 {console.error("Error fetching tasks:", e);}
}




async function updateTaskStatus(taskId, newStatus, subName)
{
 try {
   const taskRef = doc(db, `Users/${userDocID}/Tasks/${subName}/Tasks`, taskId);
   await updateDoc(taskRef, { status: newStatus });
   console.log(`Task ${taskId} status updated to ${newStatus}`);
 } catch (error) {
   console.error("Error updating task status:", error);
   alert("Error updating task status. Please try again.");
 }
}