const userData = JSON.parse(localStorage.getItem('userData'));
console.log(userData);

if(userData)
{
 const usernameElement = document.getElementById('userDataDisplay');
 usernameElement.textContent = `${userData.Name} / ${userData.MID} / ${userData.Type}`
}
else
{console.log("User data not found.");}

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, getCountFromServer, addDoc, orderBy, query} from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
// import { getStorage, ref, uploadBytes, getDownloadURL, listAll, getMetadata } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';

const firebaseConfig = 
{
 apiKey: "AIzaSyDdWJ3JPey-4Vwm-sfPbZJ--7qqZFsl1IQ",
 authDomain: "nexus-aru.firebaseapp.com",
 projectId: "nexus-aru",
 storageBucket: "nexus-aru.appspot.com",
 messagingSenderId: "473949076344",
 appId: "1:473949076344:web:d3485fb2eb4d080299268d",
 measurementId: "G-8E0DB8CRLH"
};

const firebaseapp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseapp);
// const storage = getStorage(firebaseapp);






const InputContainerImp = document.querySelector('.ImpEvents .ImpInput'); // Get the parent containeR
const InputContainerOp = document.querySelector('.OpEvents .OpInput'); // Get the parent containeR
const ImpPath = 'Events/Important/Events';
const OpPath = 'Events/Optional/Events';


function createImpInputField()
{
 const inputDiv = document.createElement('div'); // Create a div for the input area
 inputDiv.classList.add('Input'); // Add the 'Input' class for styling

 const input = document.createElement('input');
 input.type = 'text';
 input.classList.add('TypeBox');
 input.placeholder = 'Type here...';

 const sendButton = document.createElement('button');
 sendButton.classList.add('send');
 sendButton.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';


 sendButton.addEventListener('click', () => {
  const message = input.value;
  if (message.trim() !== "")
  {
   const now = new Date();
   const options = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit', 
    hour12: true 
   };

   const formattedDate = now.toLocaleDateString('en-US', options);
   try
   {
    // Add the message to Firestore
     addDoc(collection(db, ImpPath), { // 'updates' is your collection name
     message: message,
     timestamp: formattedDate, // Add a timestamp for ordering
     user: `${userData.Name} / ${userData.MID} / ${userData.Type}`
    });

    console.log("Message saved to Firestore:", message);
    input.value = ""; // Clear input field
    displayImpEvents();
   }
   catch (error)
   {
    console.error("Error saving message to Firestore:", error);
    // Handle the error (e.g., display an error message to the user)
    alert("Error sending message. Please try again later.")
   }
  }
 });


 inputDiv.appendChild(input);
 inputDiv.appendChild(sendButton);
 InputContainerImp.appendChild(inputDiv); // Add input to container
}


// Call the function to create the input field when the page loads
window.addEventListener('DOMContentLoaded', () => {
});

if(userData.Type == 'Admin')
{createImpInputField();}




function createOpInputField()
{
 const inputDiv = document.createElement('div'); // Create a div for the input area
 inputDiv.classList.add('Input'); // Add the 'Input' class for styling

 const input = document.createElement('input');
 input.type = 'text';
 input.classList.add('TypeBox');
 input.placeholder = 'Type here...';

 const sendButton = document.createElement('button');
 sendButton.classList.add('send');
 sendButton.innerHTML = '<i class="fa-solid fa-paper-plane"></i>';


 sendButton.addEventListener('click', () => {
  const message = input.value;
  if (message.trim() !== "")
  {
   const now = new Date();
   const options = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit', 
    hour12: true 
   };

   const formattedDate = now.toLocaleDateString('en-US', options);
   try
   {
    // Add the message to Firestore
     addDoc(collection(db, OpPath), { // 'updates' is your collection name
     message: message,
     timestamp: formattedDate, // Add a timestamp for ordering
     user: `${userData.Name} / ${userData.MID} / ${userData.Type}`
    });

    console.log("Message saved to Firestore:", message);
    input.value = ""; // Clear input field
    displayOpEvents();
   }
   catch (error)
   {
    console.error("Error saving message to Firestore:", error);
    // Handle the error (e.g., display an error message to the user)
    alert("Error sending message. Please try again later.")
   }
  }
 });


 inputDiv.appendChild(input);
 inputDiv.appendChild(sendButton);
 InputContainerOp.appendChild(inputDiv); // Add input to container
}


// Call the function to create the input field when the page loads
window.addEventListener('DOMContentLoaded', () => {
});

if(userData.Type == 'Admin')
{createOpInputField();}

async function displayImpEvents()
{
 const updatesContainer = document.querySelector('.ImpEvents .Events table'); // Assuming you have a table with class 'updates'
 updatesContainer.innerHTML = ''; // Clear existing updates

 try
 {
  const querySnapshot = await getDocs(
   query(collection(db, ImpPath), orderBy('timestamp', 'desc'))
  );
  querySnapshot.forEach((doc) => {
   const updateData = doc.data();
   const row = updatesContainer.insertRow();
   const cell = row.insertCell();

   const message = updateData.message;
   const timestamp = updateData.timestamp || "Unknown"; // Handle potential missing timestamps
   const user = updateData.user || "Unknown User"; // Handle cases where user data might be missing

   cell.innerHTML = `${message}<br><p>By ${user} on  ${timestamp}</p>`;
  });
 } catch (error) {
     console.error("Error fetching updates from Firestore:", error);
 }
}

displayImpEvents();




async function displayOpEvents()
{
 const updatesContainer = document.querySelector('.OpEvents .Events table'); // Assuming you have a table with class 'updates'
 updatesContainer.innerHTML = ''; // Clear existing updates

 try
 {
  const querySnapshot = await getDocs(
   query(collection(db, OpPath), orderBy('timestamp', 'desc'))
  );
  querySnapshot.forEach((doc) => {
   const updateData = doc.data();
   const row = updatesContainer.insertRow();
   const cell = row.insertCell();

   const message = updateData.message;
   const timestamp = updateData.timestamp || "Unknown"; // Handle potential missing timestamps
   const user = updateData.user || "Unknown User"; // Handle cases where user data might be missing

   cell.innerHTML = `${message}<br><p>By ${user} on  ${timestamp}</p>`;
  });
 } catch (error) {
     console.error("Error fetching updates from Firestore:", error);
 }
}

displayOpEvents();