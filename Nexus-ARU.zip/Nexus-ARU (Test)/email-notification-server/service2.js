const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');
const admin = require('firebase-admin');
const XLSX = require('xlsx');
const { getStorage } = require('firebase-admin/storage');
const fs = require('fs');
const path = require('path');

// Initialize Firebase Admin SDK
const serviceAccount = require('./serviceAccount.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: 'nexus-aru.appspot.com'
});

const db = admin.firestore();
const storage = getStorage().bucket();
const app = express();
const PORT = 3001;

app.use(cors({ origin: '*', methods: ['GET', 'POST'], allowedHeaders: ['Content-Type'] }));
app.use(bodyParser.json());

// Configure email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jeetjain1545@gmail.com',
    pass: 'imue sdup dkmj pbms'
  }
});

// Fetch recipient emails from Firestore
const getRecipientEmails = async () => {
  const recipients = [];
  try {
    const snapshot = await db.collection('Users').get();
    snapshot.forEach(doc => {
      const userData = doc.data();
      if (userData.Type === 'Student' || userData.Type === 'Admin') {
        recipients.push(`${userData.MID}@apsit.edu.in`);
      }
    });

    if (recipients.length === 0) {
      recipients.push('jeetjain1545@gmail.com');
    }
  } catch (error) {
    console.error("Error fetching emails:", error);
    recipients.push('jeetjain1545@gmail.com');
  }
  return recipients;
};

// Function to fetch and parse timetable
const getTodaysSchedule = async () => {
  try {
    const fileName = 'SE-AIML-A.xlsx';
    const tempFilePath = path.join(__dirname, fileName);

    // Download file from Firebase Storage
    await storage.file(`Other/${fileName}`).download({ destination: tempFilePath });

    // Read Excel file
    const workbook = XLSX.readFile(tempFilePath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { header: 1 });

    const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });

    let todaySchedule = [];
    for (let i = 1; i < worksheet.length; i++) {
      if (worksheet[i][0] === today) {
        for (let j = 1; j < worksheet[i].length; j++) {
          const timeSlot = worksheet[0][j]; // First row contains time slots
          const subject = worksheet[i][j] || 'Free Period';

          // Remove breaks and empty lectures
          if (subject !== '.' && subject !== 'Free Period') {
            todaySchedule.push(`${timeSlot}: ${subject}`);
          }
        }
        break;
      }
    }

    return todaySchedule.length > 0 ? todaySchedule : null;
  } catch (error) {
    console.error('Error fetching timetable:', error);
    return null;
  }
};

// Function to send timetable notification
const sendTimetableNotification = async () => {
  const recipients = await getRecipientEmails();
  const todaySchedule = await getTodaysSchedule();

  if (!todaySchedule) {
    console.log('No schedule found for today.');
    return;
  }

  const mailOptions = {
    from: 'NEXUS-ARU Notifications <jeetjain1545@gmail.com>',
    to: recipients.join(','),
    subject: 'Today’s Class Schedule',
    html: `
      <h2> Today’s Timetable</h2>
      <ul style="font-size: 16px;">
        ${todaySchedule.map(slot => `<li>${slot}</li>`).join('')}
      </ul>
      <p style="color: grey;">Stay updated with your classes.</p>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Timetable notification sent successfully.');
  } catch (error) {
    console.error('Error sending timetable email:', error);
  }
};

// Function to send event notifications
const sendEventNotification = async (message, user, timestamp) => {
  const recipients = await getRecipientEmails();

  if (recipients.length === 0) {
    console.log("No recipients found. Skipping email notification.");
    return false;
  }

  const mailOptions = {
    from: 'NEXUS-ARU Notifications <jeetjain1545@gmail.com>',
    to: recipients.join(','),
    subject: '📢 New Event Notification',
    html: `
      <h2>New Event Added</h2>
      <p><strong>Message:</strong> ${message}</p>
      <p><strong>Added by:</strong> ${user}</p>
      <p><strong>Time:</strong> ${timestamp}</p>
      <p>Login to SPMS to check details.</p>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Event notification sent successfully.');
    return true;
  } catch (error) {
    console.error('Error sending event email:', error);
    return false;
  }
};

// API endpoint for manual event notifications
app.post('/api/events', async (req, res) => {
  try {
    const { message, user, timestamp } = req.body;

    if (!message || !user || !timestamp) {
      return res.status(400).json({ success: false, error: 'Missing required fields' });
    }

    const emailSent = await sendEventNotification(message, user, timestamp);
    
    res.status(200).json({ success: true, emailSent: emailSent });
  } catch (error) {
    console.error('Error processing event notification:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Firestore listener for real-time event notifications
db.collection('Events').onSnapshot((snapshot) => {
  snapshot.docChanges().forEach((change) => {
    if (change.type === 'added') {
      const eventData = change.doc.data();
      console.log('New event detected in Firestore:', eventData);
      sendEventNotification(eventData.message, eventData.user, eventData.timestamp)
        .then(success => {
          console.log(`Email notification ${success ? 'sent' : 'failed'} for Firestore event`);
        });
    }
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Send timetable notification on server start
sendTimetableNotification();

// Start server
app.listen(PORT, () => {
  console.log(`Notification server running on port ${PORT}`);
  console.log(`API endpoint available at http://localhost:${PORT}/api/events`);
});
