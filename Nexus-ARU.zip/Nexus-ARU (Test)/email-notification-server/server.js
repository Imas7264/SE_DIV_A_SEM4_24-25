// server.js
const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');

// Add error handling for uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION: ', err);
  console.error(err.stack);
});

const app = express();
const PORT = 3001; // Use a port that's not 3000 since that's busy

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(bodyParser.json());

// Configure email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jeetjain1545@gmail.com', // Your email
    pass: 'imue sdup dkmj pbms'     // Your app password
  }
});


// List of email recipients
const recipients = [
  'jainjeet86@gmail.com',
  'phulareumesh15@gmail.com'
  // Add more recipients as needed
];

// Route to send notification for Important Events
app.post('/api/notify/important', async (req, res) => {
  try {
    const { message, user, timestamp } = req.body;
    
    // Create email content
    const mailOptions = {
      from: 'SPMS Notifications <jeetjain1545@gmail.com>', // Use your actual email
      to: recipients.join(','),
      subject: 'New Important Event Added',
      html: `
        <h2>New Important Event</h2>
        <p><strong>Message:</strong> ${message}</p>
        <p><strong>Added by:</strong> ${user}</p>
        <p><strong>Time:</strong> ${timestamp}</p>
        <p>Please log in to the SPMS system to view all events.</p>
      `
    };
    
    // Send email
    await transporter.sendMail(mailOptions);
    console.log('Important Event notification email sent successfully');
    res.status(200).json({ success: true, message: 'Email notification sent' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ success: false, message: 'Failed to send email notification' });
  }
});

// Route to send notification for Optional Events
app.post('/api/notify/optional', async (req, res) => {
  try {
    const { message, user, timestamp } = req.body;
    
    // Create email content
    const mailOptions = {
      from: 'SPMS Notifications <jeetjain1545@gmail.com>', // Use your actual email
      to: recipients.join(','),
      subject: 'New Optional Event Added',
      html: `
        <h2>New Optional Event</h2>
        <p><strong>Message:</strong> ${message}</p>
        <p><strong>Added by:</strong> ${user}</p>
        <p><strong>Time:</strong> ${timestamp}</p>
        <p>Please log in to the SPMS system to view all events.</p>
      `
    };
    
    // Send email
    await transporter.sendMail(mailOptions);
    console.log('Optional Event notification email sent successfully');
    res.status(200).json({ success: true, message: 'Email notification sent' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.status(500).json({ success: false, message: 'Failed to send email notification' });
  }
});

// Simple test route
app.get('/', (req, res) => {
  res.send('Email notification server is running!');
});

// Start server with error handling
app.listen(PORT, () => {
  console.log(`Email notification server running on port ${PORT}`);
}).on('error', (err) => {
  console.error('Server startup error:', err);
});  