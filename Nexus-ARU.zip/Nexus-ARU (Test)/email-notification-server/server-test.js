const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');
const admin = require('firebase-admin');
const XLSX = require('xlsx');
const { getStorage } = require('firebase-admin/storage');
const fs = require('fs');
const path = require('path');

// Initialize Firebase Admin SDK
const serviceAccount = require('./serviceAccount.json');
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: 'nexus-aru.appspot.com'
});

const db = admin.firestore();
const storage = getStorage().bucket();
const app = express();
const PORT = 3001;

app.use(cors({ origin: '*', methods: ['GET', 'POST'], allowedHeaders: ['Content-Type'] }));
app.use(bodyParser.json());

// Configure email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'jeetjain1545@gmail.com',
    pass: 'imue sdup dkmj pbms'
  }
});

// Fetch recipient emails from Firestore
const getRecipientEmails = async () => {
  const recipients = [];
  try {
    const snapshot = await db.collection('Users').get();
    snapshot.forEach(doc => {
      const userData = doc.data();
      if (userData.Type == 'Student' || userData.Type == 'Admin') {
        recipients.push(`${userData.MID}@apsit.edu.in`);
      }
    });

    if (recipients.length === 0) {
      recipients.push('jeetjain1545@gmail.com');
    }
  } catch (error) {
    console.error("Error fetching emails:", error);
    recipients.push('jeetjain1545@gmail.com');
  }
  return recipients;
};

// Function to fetch and parse timetable
const getTodaysSchedule = async () => {
  try {
    const fileName = 'SE-AIML-A.xlsx';
    const tempFilePath = path.join(__dirname, fileName);

    // Download file from Firebase Storage
    await storage.file(`Other/${fileName}`).download({ destination: tempFilePath });

    // Read Excel file
    const workbook = XLSX.readFile(tempFilePath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], { header: 1 });

    const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });

    // Find schedule for today
    let todaySchedule = [];
    for (let i = 1; i < worksheet.length; i++) {
      if (worksheet[i][0] === today) {
        todaySchedule = worksheet[i].slice(1);
        break;
      }
    }

    return todaySchedule.length > 0 ? todaySchedule : null;
  } catch (error) {
    console.error('Error fetching timetable:', error);
    return null;
  }
};

// Function to send email notification
const sendEmailNotification = async () => {
  const recipients = await getRecipientEmails();
  const todaySchedule = await getTodaysSchedule();

  if (!todaySchedule) {
    console.log('No schedule found for today.');
    return;
  }

  const mailOptions = {
    from: 'SPMS Notifications <jeetjain1545@gmail.com>',
    to: recipients.join(','),
    subject: 'Today’s Class Schedule',
    html: `
      <h2>Today’s Timetable</h2>
      <ul>
        ${todaySchedule.map(sub => `<li>${sub}</li>`).join('')}
      </ul>
      <p>Stay updated with your classes.</p>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Email notification sent successfully.');
  } catch (error) {
    console.error('Error sending email:', error);
  }
};

// Send timetable notification on server start
sendEmailNotification();

app.listen(PORT, () => {
  console.log(`Notification server running on port ${PORT}`);
});
